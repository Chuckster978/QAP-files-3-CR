// Desc:
// Author:
// Dates:


var $ = function (id) {
  return document.getElementById(id);
};


// Define format options for printing.
const cur2Format = new Intl.NumberFormat("en-CA", {
  style: "currency",
  currency: "CAD",
  minimumFractionDigits: "2",
  maximumFractionDigits: "2",
});

const per2Format = new Intl.NumberFormat("en-CA", {
  style: "percent",
  minimumFractionDigits: "2",
  maximumFractionDigits: "2",
});

const com2Format = new Intl.NumberFormat("en-CA", {
  style: "decimal",
  minimumFractionDigits: "2",
  maximumFractionDigits: "2",
});


// Define program constants.
//const Name = prompt("customer Name: ")
//const StreetADD = prompt("Street Address: ")
//const City = prompt("City: ")
//const PhoneNUM = prompt("Phone number: ")
//const TNOSF = prompt("Total number of sqaure feet: ")

// Start main program here.
// header 

document.writeln("<table class = 'customerinvoice'>");
document.writeln("<tr>");
document.writeln("<td colspan='2'> Mo's lawncare Services - Customer Invoice</td>");
document.writeln("</tr>")
document.writeln("</table>");

//nav
document.writeln("<table class = 'customerdisplay'>")
document.writeln("<tr>")
document.writeln("<td colspan='2'> <br />Customer Details <br /></td>");
document.writeln("</tr>")
document.writeln("<tr>")
document.writeln("<td colspan='2'> <br />" + Name + " " + StreetADD + "<br />" + City + " " + PhoneNUM + "</td>");
document.writeln("</tr>")

