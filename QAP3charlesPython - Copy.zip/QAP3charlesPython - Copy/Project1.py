#Functions Ive added to help with some of the calculations and formats
def getFirstIntial(first_name):
    Fintial = first_name[0]
    return Fintial
#This funstion takes the first letter of the first name, as python starts at 0 not 1
def Phnumber(Phonenum):
    Phonenum = "(709)" + Phonenum[:3] + '-' + Phonenum[4:]
    
    return Phonenum
#This takes the phone number and splits it into two being a 3 to 4 ratio, and inserting a dash inbetween 
def cardetail(year, carmake, carmodel):
    Cardetail = (f"{year} {carmake} {carmodel}")
    
    return Cardetail
#This combines year carmake and carmodel to create the car detail
def Receiptid(first_name, last_name, phonenum, platenum):
    ReceiptID = first_name[0] + last_name[0] + '-' + platenum[3:] + '-' + phonenum[4:]
    
    return ReceiptID

#This takes the first letter in both first and last name, plate numbers last three and the phone numbers last 4, all serperated by a dash
invoicedate = "7/15/2025"

while True:
    first_name = input("First Name:")

    if first_name == "":
        continue
    elif first_name == "END":
        break

    last_name = input("Last Name:")

    Phonenum = input("Phone Number:")
    if len(Phonenum) > 10:
        print("number must be 10 digits")
        continue

    Platenum = input("Plate Number:")
    if len(Platenum) != 6:
        print("Plate Number must be 6 digits")
        continue

    carmake = input("Car Make:")
    carmodel = input("Car Model:")
    year = int(input("Year:"))

    sellprice = float(input("Sell Price:"))
    if sellprice >= 50001.00:
        continue

    Tradeamount = float(input("Trade Amount"))
    if Tradeamount >= sellprice + 1:
        continue

    salesperson = input("Salespersons Name:")


    PriceafterTrade = sellprice - Tradeamount
    if sellprice <= 15000.00:
        licenseFee = 75.00
    elif sellprice >= 15000.01:
        licenseFee = 165.00
    transferFee = sellprice * 0.01
    luxuryFee = sellprice * 0.016
    if sellprice >= 20000.01:
        LtransferFee = transferFee + luxuryFee

    subtotal = PriceafterTrade + licenseFee 
    HST = subtotal * 0.15
    totalsalesprice = subtotal + HST

    x = 4
    monthly = 0
    finacefee = 39.99
    Totalprice = totalsalesprice + finacefee
    for i in range(x):
        monthly += 12


print("\n\n")
print(f"Honest Harry Car Sales      \t       Invoice Date:    {invoicedate}")
print(f"Used Car Sale And Reciept  \t       Reciept No: {Receiptid(first_name, last_name, Phonenum, Platenum)}")
print()
print(f"\t\t\t\t Sales Price:             ${sellprice}")
print(f"Sold to: \t\t\t Trade Allowance:         ${Tradeamount}")
print("\t\t\t\t ----------------------------------------")
print(f"     {getFirstIntial(first_name)}. {last_name}\t\t\t  Price after Trade:       {PriceafterTrade}")
print